var newId = 0;

function allowDrop(ev) {
    ev.preventDefault();
}

var img = document.createElement("img");

document.body.onmousedown = function(e) {
    e = e || window.event;
    var element = (e.target || e.srcElement);
    var elem = getNode(element);

    if (elem) {
        html2canvas(elem).then(function(canvas) {
            img.src = canvas.toDataURL("image/png");
        });
    }

    function getNode(element) {
        if (element.getAttribute("draggable") == "true") {
            return element;
        } else if ($(element).is("body")) {
            return null;
        } else {
            return getNode(element.parentNode);
        }
    }
}

function drag(ev) {
    ev.dataTransfer.setData("text/html", ev.target.id);
    ev.dataTransfer.setDragImage(img, img.naturalWidth / 2, img.naturalHeight / 2);
    $('[data-toggle=popover]').each(function() {
        $(this).popover('hide');
    });
}

function drop(ev) {
    ev.preventDefault();
    ev.stopPropagation();

    if (!ev.target.getAttribute("ondrop")) {
        return false;
    }
    var data = ev.dataTransfer.getData("text/html");
    // ev.target.appendChild(document.getElementById(data));
    var nodeCopy = document.getElementById(data).cloneNode(true);
    newId++;
    nodeCopy.id = newId; /* We cannot use the same ID */
    nodeCopy.setAttribute("data-toggle", "popover");
    nodeCopy.setAttribute("data-placement", "right");
    // chipl initiated popover before first click
    $(nodeCopy).popover({
        html: true,
        trigger: 'click',
        content: function() {
            $('[data-toggle=popover]').each(function() {
                // hide any open popovers when the anywhere else in the body is clicked
                // // if (!$(this).is(evt.target) && $(this).has(evt.target).length === 0 && $('.popover').has(evt.target).length === 0) {  
                if (this != nodeCopy) {
                    $(this).popover('hide');
                }
            });
            //var obj = $(this).parents('.popover.in').prev();
            console.log('clicked object: ', nodeCopy.id, $(this).data('bs.popover'));
            return $('#popover-content').html();
        }
    });

    ev.target.appendChild(nodeCopy);
}
// Sortable function
$(function() {
    var sortableDiv = document.querySelector("#div2");
    // console.log(sortableDiv);
    $(sortableDiv).sortable({
        receive: function(e, ui) { sortableIn = 1; },
        start: function(e, ui) {
            // modify ui.placeholder however you like
            // ui.placeholder.html("I'm modifying the placeholder element!");
        },
        sort: function(e) {
            // console.log('X:' + e.screenX, 'Y:' + e.screenY);
            $('[data-toggle=popover]').each(function() {
                // hide any open popovers when the anywhere else in the body is clicked                
                $(this).popover('hide');
            });

        },
        placeholder: "ui-sortable-placeholder",
        over: function(e, ui) { sortableIn = 1; },
        out: function(e, ui) { sortableIn = 0; },
        beforeStop: function(e, ui) {
            if (sortableIn == 0) {
                //ui.item.remove();
                $(ui.item.context).popover('destroy');
                $('[data-toggle=popover]').each(function() {
                    // hide any open popovers when the anywhere else in the body is clicked
                    // // if (!$(this).is(evt.target) && $(this).has(evt.target).length === 0 && $('.popover').has(evt.target).length === 0) {                     
                    $(this).popover('hide');
                });
                ui.item.remove();
                //console.log("may remove item here", ui.item.context);
            }
        }
    });
    $(sortableDiv).disableSelection();
})
