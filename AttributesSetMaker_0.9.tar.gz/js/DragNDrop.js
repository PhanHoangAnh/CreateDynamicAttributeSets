var newId = 0;

function allowDrop(ev) {
    ev.preventDefault();
}

var img = document.createElement("img");

document.body.onmousedown = function(e) {
    e = e || window.event;
    var element = (e.target || e.srcElement);
    var elem = getNode(element);
   
    if (elem) {
        html2canvas(elem).then(function(canvas) {
            img.src = canvas.toDataURL("image/png");
        });
    }

    function getNode(element) {
        if (element.getAttribute("draggable") == "true") {
            return element;
        } else if ($(element).is("body")) {
            return null;
        } else {
            return getNode(element.parentNode);
        }
    }
}

function drag(ev) {
    ev.dataTransfer.setData("text/html", ev.target.id);
    
    ev.dataTransfer.setDragImage(img, img.naturalWidth/2, img.naturalHeight/2)

    $('[data-toggle=popover]').each(function() {
        $(this).popover('hide');
    });
}

function drop(ev) {
    ev.preventDefault();
    //ev.stopPropagation();

    if (!ev.target.getAttribute("ondrop")) {
        return false;
    }
    var data = ev.dataTransfer.getData("text/html");
    // ev.target.appendChild(document.getElementById(data));
    var nodeCopy = document.getElementById(data).cloneNode(true);
    newId++;
    nodeCopy.id = newId; /* We cannot use the same ID */
    nodeCopy.setAttribute("data-toggle", "popover");
    nodeCopy.setAttribute("data-placement", "right");
    $(nodeCopy).popover({
        html: true,
        trigger: 'click',
        content: function() {
            $('[data-toggle=popover]').each(function() {
                // hide any open popovers when the anywhere else in the body is clicked
                // // if (!$(this).is(evt.target) && $(this).has(evt.target).length === 0 && $('.popover').has(evt.target).length === 0) {  
                if (this != nodeCopy) {
                    $(this).popover('hide');
                }
            });
            return $('#popover-content').html();
        }
    })
    ev.target.appendChild(nodeCopy);
}

function dragEnd(ev) {
    var parentNode = ev.target.parentNode;
    parentNode.removeChild(ev.target);
    $(this).popover('hide');
}
